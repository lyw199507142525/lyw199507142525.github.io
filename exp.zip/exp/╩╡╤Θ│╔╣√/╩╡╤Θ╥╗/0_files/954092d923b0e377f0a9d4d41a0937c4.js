var _a = new Image();
_a.src = "http://xls.go.sohu.com/201009/954092d923b0e377f0a9d4d41a0937c4.php?a=99";
document.pv.push(_a);
